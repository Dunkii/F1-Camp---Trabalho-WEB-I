from django import forms
from .models import Piloto, Equipe, Circuito, Temporada, Resultado, Pontuacao, Classificacao, Carro, Penalidade, Corrida, TipoCorrida

class PilotoForm(forms.ModelForm):
    class Meta:
        model = Piloto
        fields = ['nome', 'nacionalidade', 'numero', 'equipe']
        widgets = {
            'nome': forms.TextInput(attrs={'class': 'form-control'}),
            'nacionalidade': forms.TextInput(attrs={'class': 'form-control'}),
            'numero': forms.NumberInput(attrs={'class': 'form-control'}),
            'equipe': forms.Select(attrs={'class': 'form-control'}),
        }

class EquipeForm(forms.ModelForm):
    class Meta:
        model = Equipe
        fields = ['nome', 'pais', 'motor']
        widgets = {
            'nome': forms.TextInput(attrs={'class': 'form-control'}),
            'pais': forms.TextInput(attrs={'class': 'form-control'}),
            'motor': forms.TextInput(attrs={'class': 'form-control'}),
        }

class CircuitoForm(forms.ModelForm):
    class Meta:
        model = Circuito
        fields = ['nome', 'localizacao', 'distancia', 'numero_voltas']
        widgets = {
            'nome': forms.TextInput(attrs={'class': 'form-control'}),
            'localizacao': forms.TextInput(attrs={'class': 'form-control'}),
            'distancia': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'numero_voltas': forms.NumberInput(attrs={'class': 'form-control'}),
        }

class TemporadaForm(forms.ModelForm):
    class Meta:
        model = Temporada
        fields = ['ano', 'numero_corridas', 'vencedor']
        widgets = {
            'ano': forms.NumberInput(attrs={'class': 'form-control'}),
            'numero_corridas': forms.NumberInput(attrs={'class': 'form-control'}),
            'vencedor': forms.Select(attrs={'class': 'form-control'}),
        }

class ResultadoForm(forms.ModelForm):
    class Meta:
        model = Resultado
        fields = ['piloto', 'corrida', 'temporada', 'posicao_final', 'pontuacao']
        widgets = {
            'piloto': forms.Select(attrs={'class': 'form-control'}),
            'corrida': forms.Select(attrs={'class': 'form-control'}),
            'temporada': forms.Select(attrs={'class': 'form-control'}),
            'posicao_final': forms.NumberInput(attrs={'class': 'form-control'}),
            'pontuacao': forms.Select(attrs={'class': 'form-control'}),
        }
        labels = {
            'posicao_final': 'Posição Final (Resultado)',
        }

class PontuacaoForm(forms.ModelForm):
    class Meta:
        model = Pontuacao
        fields = ['tipo_corrida', 'posicao', 'pontos']
        widgets = {
            'tipo_corrida': forms.Select(attrs={'class': 'form-control'}),
            'posicao': forms.NumberInput(attrs={'class': 'form-control'}),
            'pontos': forms.NumberInput(attrs={'class': 'form-control'}),
        }

class ClassificacaoForm(forms.ModelForm):
    class Meta:
        model = Classificacao
        fields = ['temporada', 'piloto', 'pontos_totais']
        widgets = {
            'temporada': forms.Select(attrs={'class': 'form-control'}),
            'piloto': forms.Select(attrs={'class': 'form-control'}),
            'pontos_totais': forms.NumberInput(attrs={'class': 'form-control'}),
        }

class CarroForm(forms.ModelForm):
    class Meta:
        model = Carro
        fields = ['modelo', 'equipe', 'temporada', 'ano', 'motor']
        widgets = {
            'modelo': forms.TextInput(attrs={'class': 'form-control'}),
            'equipe': forms.Select(attrs={'class': 'form-control'}),
            'temporada': forms.Select(attrs={'class': 'form-control'}),
            'ano': forms.NumberInput(attrs={'class': 'form-control'}),
            'motor': forms.TextInput(attrs={'class': 'form-control'}),
        }

class PenalidadeForm(forms.ModelForm):
    class Meta:
        model = Penalidade
        fields = ['piloto', 'corrida', 'motivo', 'tipo_penalidade', 'penalidade_aplicada']
        widgets = {
            'piloto': forms.Select(attrs={'class': 'form-control'}),
            'corrida': forms.Select(attrs={'class': 'form-control'}),
            'motivo': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'tipo_penalidade': forms.Select(attrs={'class': 'form-control'}),
            'penalidade_aplicada': forms.TextInput(attrs={'class': 'form-control'}),
        }

class CorridaForm(forms.ModelForm):
    class Meta:
        model = Corrida
        fields = ['nome', 'data', 'circuito', 'temporada', 'tipo_corrida']
        widgets = {
            'nome': forms.TextInput(attrs={'class': 'form-control'}),
            'data': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
            'circuito': forms.Select(attrs={'class': 'form-control'}),
            'temporada': forms.Select(attrs={'class': 'form-control'}),
            'tipo_corrida': forms.Select(attrs={'class': 'form-control'}),
        }