from django.db import transaction
from django.db.models.signals import pre_save, post_save, post_delete
from django.dispatch import receiver
from .models import Resultado, Classificacao, Pontuacao, Penalidade

@receiver(pre_save, sender=Resultado)
def salvar_posicao_original(sender, instance, **kwargs):
    if instance.pk is None:
        instance.posicao_original = instance.posicao_final

def recalcular_corrida_com_penalidades(corrida):
    with transaction.atomic():
        resultados = list(corrida.resultados.all())
        penalidades_existentes = Penalidade.objects.filter(corrida=corrida)
        posicoes_map = {res.piloto: res.posicao_original for res in resultados}

        for penalidade in penalidades_existentes:
            if penalidade.piloto in posicoes_map:
                try:
                    posicoes_perdidas = 1 + int(penalidade.penalidade_aplicada.replace('+','').replace(' posições','').strip())
                    posicoes_map[penalidade.piloto] += posicoes_perdidas
                except (ValueError, AttributeError):
                    pass

        pilotos_ordenados = sorted(posicoes_map, key=posicoes_map.get)

        for nova_posicao, piloto in enumerate(pilotos_ordenados, 1):
            res = Resultado.objects.get(corrida=corrida, piloto=piloto)
            res.posicao_final = nova_posicao
            
            try:
                pontuacao_regra = Pontuacao.objects.get(
                    tipo_corrida=corrida.tipo_corrida,
                    posicao=res.posicao_final
                )
                res.pontuacao = pontuacao_regra
            except Pontuacao.DoesNotExist:
                res.pontuacao = None

            res.save()
            
    for res in Resultado.objects.filter(corrida=corrida):
        atualizar_classificacao(sender=Resultado, instance=res)

@receiver(post_save, sender=Resultado)
def atualizar_classificacao(sender, instance, **kwargs):
    resultado = instance
    piloto = resultado.piloto
    corrida = resultado.corrida

    classificacao_piloto, created = Classificacao.objects.get_or_create(
        piloto=piloto,
        temporada=corrida.temporada,
        defaults={'pontos_totais': 0}
    )

    pontos_totais_calculados = 0
    resultados_do_piloto = Resultado.objects.filter(
        piloto=piloto,
        corrida__temporada=corrida.temporada
    )
    
    for res in resultados_do_piloto:
        pontos_totais_calculados += res.pontuacao.pontos if res.pontuacao else 0

    classificacao_piloto.pontos_totais = pontos_totais_calculados
    classificacao_piloto.save()

@receiver(post_save, sender=Penalidade)
def gerenciar_penalidade_salva(sender, instance, **kwargs):
    recalcular_corrida_com_penalidades(instance.corrida)

@receiver(post_delete, sender=Penalidade)
def gerenciar_penalidade_excluida(sender, instance, **kwargs):
    recalcular_corrida_com_penalidades(instance.corrida)