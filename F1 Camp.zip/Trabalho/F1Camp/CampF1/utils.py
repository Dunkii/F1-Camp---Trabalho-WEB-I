from .models import Temporada, Resultado, Pontuacao, Classificacao
from django.db.models import Sum

def calculate_season_standings(season_id):
    try:
        temporada = Temporada.objects.get(pk=season_id)
    except Temporada.DoesNotExist:
        print(f"Temporada com ID {season_id} não encontrada.")
        return

    pontuacoes_map = {p.posicao: p.pontos for p in Pontuacao.objects.filter(temporada=temporada)}
    resultados_temporada = Resultado.objects.filter(temporada=temporada)

    piloto_pontos = {}
    for resultado in resultados_temporada:
        pontos = pontuacoes_map.get(resultado.posicao_final, 0)
        piloto_pontos[resultado.piloto] = piloto_pontos.get(resultado.piloto, 0) + pontos

    for piloto, pontos_totais in piloto_pontos.items():
        classificacao, created = Classificacao.objects.update_or_create(
            temporada=temporada,
            piloto=piloto,
            defaults={'pontos_totais': pontos_totais}
        )
        if not created:
            print(f"Atualizado Classificação para {piloto.nome} na Temporada {temporada.ano}")
        else:
            print(f"Criado Classificação para {piloto.nome} na Temporada {temporada.ano}")

    final_standings = Classificacao.objects.filter(temporada=temporada).order_by('-pontos_totais')
    if final_standings.exists():
        temporada.vencedor = final_standings.first().piloto
        temporada.save()
        print(f"Vencedor da Temporada {temporada.ano}: {temporada.vencedor.nome}")
    else:
        temporada.vencedor = None
        temporada.save()
        print(f"Nenhum vencedor para a Temporada {temporada.ano} ainda.")