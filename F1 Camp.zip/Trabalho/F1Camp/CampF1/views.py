from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from datetime import date
from .models import (Piloto, Equipe, Corrida, Circuito, Resultado, Temporada, Pontuacao, Classificacao, Carro, Penalidade)
from .forms import (PilotoForm, EquipeForm, CircuitoForm, TemporadaForm, ResultadoForm, PontuacaoForm, ClassificacaoForm, CarroForm, PenalidadeForm, CorridaForm)

def home(request):
    today = date.today()
    latest_race = Corrida.objects.filter(data__lte=today).order_by('-data').first()
    next_race = Corrida.objects.filter(data__gte=today).order_by('data').first()
    latest_season = Temporada.objects.order_by('-ano').first()
    if latest_season:
        top_pilots = Classificacao.objects.filter(temporada=latest_season).order_by('-pontos_totais')[:5]
    else:
        top_pilots = []

    context = {
        'latest_race': latest_race,
        'next_race': next_race,
        'latest_season': latest_season,
        'top_pilots': top_pilots,
    }
    return render(request, 'CampF1/home.html', context)

def piloto_list(request):
    pilotos = Piloto.objects.all().order_by('nome')
    return render(request, 'CampF1/piloto_list.html', {'pilotos': pilotos})

def piloto_detail(request, pk):
    piloto = get_object_or_404(Piloto, pk=pk)
    resultados = Resultado.objects.filter(piloto=piloto).order_by('-corrida__data')[:10]
    penalidades = Penalidade.objects.filter(piloto=piloto).order_by('-corrida__data')[:5]
    return render(request, 'CampF1/piloto_detail.html', {
        'piloto': piloto,
        'resultados': resultados,
        'penalidades': penalidades
    })

def equipe_list(request):
    equipes = Equipe.objects.all().order_by('nome')
    return render(request, 'CampF1/equipe_list.html', {'equipes': equipes})

def equipe_detail(request, pk):
    equipe = get_object_or_404(Equipe, pk=pk)
    pilotos = Piloto.objects.filter(equipe=equipe)
    carros = Carro.objects.filter(equipe=equipe).order_by('-ano')
    return render(request, 'CampF1/equipe_detail.html', {
        'equipe': equipe,
        'pilotos': pilotos,
        'carros': carros
    })

def corrida_list(request):
    corridas = Corrida.objects.all().order_by('-data')
    return render(request, 'CampF1/corrida_list.html', {'corridas': corridas})

def corrida_detail(request, pk):
    corrida = get_object_or_404(Corrida, pk=pk)
    resultados = Resultado.objects.filter(corrida=corrida).order_by('posicao_final')
    penalidades = Penalidade.objects.filter(corrida=corrida)
    return render(request, 'CampF1/corrida_detail.html', {
        'corrida': corrida,
        'resultados': resultados,
        'penalidades': penalidades
    })

def temporada_list(request):
    temporadas = Temporada.objects.all().order_by('-ano')
    return render(request, 'CampF1/temporada_list.html', {'temporadas': temporadas})

def temporada_detail(request, pk):
    temporada = get_object_or_404(Temporada, pk=pk)
    corridas = Corrida.objects.filter(temporada=temporada).order_by('data')
    classificacao = Classificacao.objects.filter(temporada=temporada).order_by('-pontos_totais')
    return render(request, 'CampF1/temporada_detail.html', {
        'temporada': temporada,
        'corridas': corridas,
        'classificacao': classificacao
    })

def classificacao_temporada(request, temporada_id):
    temporada = get_object_or_404(Temporada, pk=temporada_id)
    classificacao = Classificacao.objects.filter(temporada=temporada).order_by('-pontos_totais')
    return render(request, 'CampF1/classificacao_temporada.html', {
        'temporada': temporada,
        'classificacao': classificacao
    })

def circuito_list(request):
    circuitos = Circuito.objects.all().order_by('nome')
    return render(request, 'CampF1/circuito_list.html', {'circuitos': circuitos})

def circuito_detail(request, pk):
    circuito = get_object_or_404(Circuito, pk=pk)
    corridas_no_circuito = Corrida.objects.filter(circuito=circuito).order_by('-data')[:10]
    return render(request, 'CampF1/circuito_detail.html', {
        'circuito': circuito,
        'corridas_no_circuito': corridas_no_circuito
    })

def pontuacao_list(request):
    pontuacoes = Pontuacao.objects.all().order_by('tipo_corrida', 'posicao')
    
    return render(request, 'CampF1/pontuacao_list.html', {'pontuacoes': pontuacoes})

def pontuacao_detail(request, pk):
    pontuacao = get_object_or_404(Pontuacao, pk=pk)
    return render(request, 'CampF1/pontuacao_detail.html', {'pontuacao': pontuacao})

def carro_list(request):
    carros = Carro.objects.all().order_by('-ano', 'equipe__nome')
    return render(request, 'CampF1/carro_list.html', {'carros': carros})

def carro_detail(request, pk):
    carro = get_object_or_404(Carro, pk=pk)
    return render(request, 'CampF1/carro_detail.html', {'carro': carro})

def penalidade_list(request):
    penalidades = Penalidade.objects.all().order_by('-corrida__data', 'piloto__nome')
    return render(request, 'CampF1/penalidade_list.html', {'penalidades': penalidades})

def penalidade_detail(request, pk):
    penalidade = get_object_or_404(Penalidade, pk=pk)
    return render(request, 'CampF1/penalidade_detail.html', {'penalidade': penalidade})

@login_required
def piloto_create(request):
    if request.method == 'POST':
        form = PilotoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Piloto adicionado com sucesso!')
            return redirect('piloto_list')
    else:
        form = PilotoForm()
    return render(request, 'CampF1/piloto_form.html', {'form': form, 'title': 'Adicionar Piloto'})

@login_required
def piloto_update(request, pk):
    piloto = get_object_or_404(Piloto, pk=pk)
    if request.method == 'POST':
        form = PilotoForm(request.POST, instance=piloto)
        if form.is_valid():
            form.save()
            messages.success(request, 'Piloto atualizado com sucesso!')
            return redirect('piloto_detail', pk=piloto.pk)
    else:
        form = PilotoForm(instance=piloto)
    return render(request, 'CampF1/piloto_form.html', {'form': form, 'title': f'Editar Piloto: {piloto.nome}'})

@login_required
def piloto_delete(request, pk):
    piloto = get_object_or_404(Piloto, pk=pk)
    if request.method == 'POST':
        piloto.delete()
        messages.warning(request, 'Piloto excluído com sucesso!')
        return redirect('piloto_list')
    return render(request, 'CampF1/piloto_confirm_delete.html', {'piloto': piloto})

@login_required
def equipe_create(request):
    if request.method == 'POST':
        form = EquipeForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Equipe adicionada com sucesso!')
            return redirect('equipe_list')
    else:
        form = EquipeForm()
    return render(request, 'CampF1/equipe_form.html', {'form': form, 'title': 'Adicionar Equipe'})

@login_required
def equipe_update(request, pk):
    equipe = get_object_or_404(Equipe, pk=pk)
    if request.method == 'POST':
        form = EquipeForm(request.POST, instance=equipe)
        if form.is_valid():
            form.save()
            messages.success(request, 'Equipe atualizada com sucesso!')
            return redirect('equipe_detail', pk=equipe.pk)
    else:
        form = EquipeForm(instance=equipe)
    return render(request, 'CampF1/equipe_form.html', {'form': form, 'title': f'Editar Equipe: {equipe.nome}'})

@login_required
def equipe_delete(request, pk):
    equipe = get_object_or_404(Equipe, pk=pk)
    if request.method == 'POST':
        equipe.delete()
        messages.warning(request, 'Equipe excluída com sucesso!')
        return redirect('equipe_list')
    return render(request, 'CampF1/equipe_confirm_delete.html', {'equipe': equipe})

@login_required
def circuito_create(request):
    if request.method == 'POST':
        form = CircuitoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Circuito adicionado com sucesso!')
            return redirect('circuito_list')
    else:
        form = CircuitoForm()
    return render(request, 'CampF1/circuito_form.html', {'form': form, 'title': 'Adicionar Circuito'})

@login_required
def circuito_update(request, pk):
    circuito = get_object_or_404(Circuito, pk=pk)
    if request.method == 'POST':
        form = CircuitoForm(request.POST, instance=circuito)
        if form.is_valid():
            form.save()
            messages.success(request, 'Circuito atualizado com sucesso!')
            return redirect('circuito_detail', pk=circuito.pk)
    else:
        form = CircuitoForm(instance=circuito)
    return render(request, 'CampF1/circuito_form.html', {'form': form, 'title': f'Editar Circuito: {circuito.nome}'})

@login_required
def circuito_delete(request, pk):
    circuito = get_object_or_404(Circuito, pk=pk)
    if request.method == 'POST':
        circuito.delete()
        messages.warning(request, 'Circuito excluído com sucesso!')
        return redirect('circuito_list')
    return render(request, 'CampF1/circuito_confirm_delete.html', {'circuito': circuito})

@login_required
def temporada_create(request):
    if request.method == 'POST':
        form = TemporadaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Temporada adicionada com sucesso!')
            return redirect('temporada_list')
    else:
        form = TemporadaForm()
    return render(request, 'CampF1/temporada_form.html', {'form': form, 'title': 'Adicionar Temporada'})

@login_required
def temporada_update(request, pk):
    temporada = get_object_or_404(Temporada, pk=pk)
    if request.method == 'POST':
        form = TemporadaForm(request.POST, instance=temporada)
        if form.is_valid():
            form.save()
            messages.success(request, 'Temporada atualizada com sucesso!')
            return redirect('temporada_detail', pk=temporada.pk)
    else:
        form = TemporadaForm(instance=temporada)
    return render(request, 'CampF1/temporada_form.html', {'form': form, 'title': f'Editar Temporada: {temporada.ano}'})

@login_required
def temporada_delete(request, pk):
    temporada = get_object_or_404(Temporada, pk=pk)
    if request.method == 'POST':
        temporada.delete()
        messages.warning(request, 'Temporada excluída com sucesso!')
        return redirect('temporada_list')
    return render(request, 'CampF1/temporada_confirm_delete.html', {'temporada': temporada})

@login_required
def resultado_create(request):
    if request.method == 'POST':
        form = ResultadoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Resultado adicionado com sucesso!')
            return redirect('corrida_detail', pk=form.cleaned_data['corrida'].pk)
    else:
        form = ResultadoForm()
    return render(request, 'CampF1/resultado_form.html', {'form': form, 'title': 'Adicionar Resultado'})

@login_required
def resultado_update(request, pk):
    resultado = get_object_or_404(Resultado, pk=pk)
    if request.method == 'POST':
        form = ResultadoForm(request.POST, instance=resultado)
        if form.is_valid():
            form.save()
            messages.success(request, 'Resultado atualizado com sucesso!')
            return redirect('corrida_detail', pk=resultado.corrida.pk)
    else:
        form = ResultadoForm(instance=resultado)
    return render(request, 'CampF1/resultado_form.html', {'form': form, 'title': f'Editar Resultado para {resultado.piloto.nome}'})

@login_required
def resultado_delete(request, pk):
    resultado = get_object_or_404(Resultado, pk=pk)
    if request.method == 'POST':
        corrida_pk = resultado.corrida.pk
        resultado.delete()
        messages.warning(request, 'Resultado excluído com sucesso!')
        return redirect('corrida_detail', pk=corrida_pk)
    return render(request, 'CampF1/resultado_confirm_delete.html', {'resultado': resultado})

@login_required
def pontuacao_create(request):
    if request.method == 'POST':
        form = PontuacaoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Pontuação adicionada com sucesso!')
            return redirect('pontuacao_list') 
        else:
            print(form.errors)
    else:
        form = PontuacaoForm()

    return render(request, 'CampF1/pontuacao_form.html', {'form': form, 'title': 'Adicionar Pontuação'})

@login_required
def pontuacao_update(request, pk):
    pontuacao = get_object_or_404(Pontuacao, pk=pk)
    if request.method == 'POST':
        form = PontuacaoForm(request.POST, instance=pontuacao)
        if form.is_valid():
            form.save()
            messages.success(request, 'Pontuação atualizada com sucesso!')
            return redirect('pontuacao_list')
    else:
        form = PontuacaoForm(instance=pontuacao)
    
    title = f'Editar Pontuação: {pontuacao.tipo_corrida.tipo} - {pontuacao.posicao}º'
    
    return render(request, 'CampF1/pontuacao_form.html', {'form': form, 'title': title})

@login_required
def pontuacao_delete(request, pk):
    pontuacao = get_object_or_404(Pontuacao, pk=pk)
    if request.method == 'POST':
        pontuacao.delete()
        messages.warning(request, 'Pontuação excluída com sucesso!')
        return redirect('pontuacao_list')
    return render(request, 'CampF1/pontuacao_confirm_delete.html', {'pontuacao': pontuacao})

@login_required
def classificacao_create(request):
    if request.method == 'POST':
        form = ClassificacaoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Classificação adicionada com sucesso!')
            return redirect('classificacao_temporada', temporada_id=form.cleaned_data['temporada'].pk)
    else:
        form = ClassificacaoForm()
    return render(request, 'CampF1/classificacao_form.html', {'form': form, 'title': 'Adicionar Classificação'})

@login_required
def classificacao_update(request, pk):
    classificacao = get_object_or_404(Classificacao, pk=pk)
    if request.method == 'POST':
        form = ClassificacaoForm(request.POST, instance=classificacao)
        if form.is_valid():
            form.save()
            messages.success(request, 'Classificação atualizada com sucesso!')
            return redirect('classificacao_temporada', temporada_id=classificacao.temporada.pk)
    else:
        form = ClassificacaoForm(instance=classificacao)
    return render(request, 'CampF1/classificacao_form.html', {'form': form, 'title': f'Editar Classificação para {classificacao.piloto.nome} ({classificacao.temporada.ano})'})

@login_required
def classificacao_delete(request, pk):
    classificacao = get_object_or_404(Classificacao, pk=pk)
    if request.method == 'POST':
        temporada_pk = classificacao.temporada.pk
        classificacao.delete()
        messages.warning(request, 'Classificação excluída com sucesso!')
        return redirect('classificacao_temporada', temporada_id=temporada_pk)
    return render(request, 'CampF1/classificacao_confirm_delete.html', {'classificacao': classificacao})

@login_required
def corrida_create(request):
    if request.method == 'POST':
        form = CorridaForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Corrida adicionada com sucesso!')
            return redirect('corrida_list')
    else:
        form = CorridaForm()
    return render(request, 'CampF1/corrida_form.html', {'form': form, 'title': 'Adicionar Corrida'})

@login_required
def corrida_update(request, pk):
    corrida = get_object_or_404(Corrida, pk=pk)
    if request.method == 'POST':
        form = CorridaForm(request.POST, instance=corrida)
        if form.is_valid():
            form.save()
            messages.success(request, 'Corrida atualizada com sucesso!')
            return redirect('corrida_detail', pk=corrida.pk)
    else:
        form = CorridaForm(instance=corrida)
    return render(request, 'CampF1/corrida_form.html', {'form': form, 'title': f'Editar Corrida: {corrida.nome}'})

@login_required
def corrida_delete(request, pk):
    corrida = get_object_or_404(Corrida, pk=pk)
    if request.method == 'POST':
        corrida.delete()
        messages.warning(request, 'Corrida excluída com sucesso!')
        return redirect('corrida_list')
    return render(request, 'CampF1/corrida_confirm_delete.html', {'corrida': corrida})

@login_required
def carro_create(request):
    if request.method == 'POST':
        form = CarroForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Carro adicionado com sucesso!')
            return redirect('carro_list')
    else:
        initial_data = {}
        if 'equipe' in request.GET:
            initial_data['equipe'] = request.GET.get('equipe')
        if 'temporada' in request.GET:
            initial_data['temporada'] = request.GET.get('temporada')
        form = CarroForm(initial=initial_data)

    return render(request, 'CampF1/carro_form.html', {'form': form, 'title': 'Adicionar Carro'})

@login_required
def carro_update(request, pk):
    carro = get_object_or_404(Carro, pk=pk)
    if request.method == 'POST':
        form = CarroForm(request.POST, instance=carro)
        if form.is_valid():
            form.save()
            messages.success(request, f'Carro "{carro.modelo}" atualizado com sucesso!')
            return redirect('carro_detail', pk=carro.pk)
    else:
        form = CarroForm(instance=carro)
    return render(request, 'CampF1/carro_form.html', {'form': form, 'title': f'Editar Carro: {carro.modelo}'})

@login_required
def carro_delete(request, pk):
    carro = get_object_or_404(Carro, pk=pk)
    if request.method == 'POST':
        carro.delete()
        messages.warning(request, f'Carro "{carro.modelo}" excluído com sucesso!')
        return redirect('carro_list')
    return render(request, 'CampF1/carro_confirm_delete.html', {'carro': carro})

@login_required
def penalidade_create(request):
    if request.method == 'POST':
        form = PenalidadeForm(request.POST)
        if form.is_valid():
            penalidade = form.save()
            messages.success(request, 'Penalidade adicionada com sucesso!')
            return redirect('corrida_detail', pk=penalidade.corrida.pk)
    else:
        initial_data = {}
        if 'corrida' in request.GET:
            initial_data['corrida'] = request.GET.get('corrida')
        if 'piloto' in request.GET:
            initial_data['piloto'] = request.GET.get('piloto')
        form = PenalidadeForm(initial=initial_data)

    return render(request, 'CampF1/penalidade_form.html', {'form': form, 'title': 'Adicionar Penalidade'})

@login_required
def penalidade_update(request, pk):
    penalidade = get_object_or_404(Penalidade, pk=pk)
    if request.method == 'POST':
        form = PenalidadeForm(request.POST, instance=penalidade)
        if form.is_valid():
            form.save()
            messages.success(request, 'Penalidade atualizada com sucesso!')
            return redirect('penalidade_detail', pk=penalidade.pk)
    else:
        form = PenalidadeForm(instance=penalidade)
    return render(request, 'CampF1/penalidade_form.html', {'form': form, 'title': f'Editar Penalidade para {penalidade.piloto.nome}'})

@login_required
def penalidade_delete(request, pk):
    penalidade = get_object_or_404(Penalidade, pk=pk)
    if request.method == 'POST':
        corrida_pk = penalidade.corrida.pk
        penalidade.delete()
        messages.warning(request, 'Penalidade excluída com sucesso!')
        return redirect('corrida_detail', pk=corrida_pk)
    return render(request, 'CampF1/penalidade_confirm_delete.html', {'penalidade': penalidade})

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, 'Conta criada com sucesso! Você já está logado.')
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Erro no cadastro. Por favor, corrija os erros abaixo.')
    else:
        form = UserCreationForm()
    return render(request, 'registration/cadastro.html', {'form': form, 'title': 'Cadastro de Usuário'})