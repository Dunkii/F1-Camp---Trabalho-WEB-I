from django.db import models

class Equipe(models.Model):
    nome = models.CharField(max_length=100)
    pais = models.CharField(max_length=100)
    motor = models.CharField(max_length=100)

    def __str__(self):
        return self.nome

class Piloto(models.Model):
    nome = models.CharField(max_length=100)
    nacionalidade = models.CharField(max_length=100)
    numero = models.IntegerField()
    equipe = models.ForeignKey(Equipe, on_delete=models.SET_NULL, null=True, blank=True, related_name='pilotos')

    def __str__(self):
        return self.nome

class Circuito(models.Model):
    nome = models.CharField(max_length=100)
    localizacao = models.CharField(max_length=200)
    distancia = models.FloatField()
    numero_voltas = models.IntegerField()

    def __str__(self):
        return self.nome

class Temporada(models.Model):
    ano = models.IntegerField(unique=True)
    numero_corridas = models.IntegerField()
    vencedor = models.ForeignKey(Piloto, on_delete=models.SET_NULL, null=True, blank=True, related_name='temporadas_vencidas')

    def __str__(self):
        return f"Temporada {self.ano}"

class Corrida(models.Model):
    nome = models.CharField(max_length=100)
    data = models.DateField()
    circuito = models.ForeignKey(Circuito, on_delete=models.CASCADE, related_name='corridas')
    temporada = models.ForeignKey(Temporada, on_delete=models.CASCADE, related_name='corridas')
    tipo_corrida = models.ForeignKey(
        'TipoCorrida',
        on_delete=models.CASCADE,
        related_name='corridas',
        verbose_name="Tipo de Corrida"
    )

    def __str__(self):
        return f"{self.nome} ({self.temporada.ano})"
    
class TipoCorrida(models.Model):
    TIPO_CORRIDA_CHOICES = [
        ('Sprint', 'Sprint'),
        ('Principal', 'Principal'),
    ]
    tipo = models.CharField(
        max_length=10,
        choices=TIPO_CORRIDA_CHOICES,
        unique=True,
        verbose_name="Tipo de Corrida"
    )

    class Meta:
        verbose_name = "Tipo de Corrida"
        verbose_name_plural = "Tipos de Corrida"

    def __str__(self):
        return self.tipo

class Pontuacao(models.Model):
    tipo_corrida = models.ForeignKey(
        TipoCorrida,
        on_delete=models.CASCADE,
        related_name='pontuacoes_por_tipo',
        verbose_name="Tipo de Corrida"
    )
    posicao = models.IntegerField()
    pontos = models.IntegerField()

    class Meta:
        unique_together = ('tipo_corrida', 'posicao')
        verbose_name = "Pontuação"
        verbose_name_plural = "Pontuações"

    def __str__(self):
        return f"{self.tipo_corrida.tipo} - Posição {self.posicao}: {self.pontos} pontos"


class Resultado(models.Model):
    piloto = models.ForeignKey(Piloto, on_delete=models.CASCADE, related_name='resultados')
    corrida = models.ForeignKey(Corrida, on_delete=models.CASCADE, related_name='resultados')
    temporada = models.ForeignKey(Temporada, on_delete=models.CASCADE, related_name='resultados_temporada')
    posicao_original = models.IntegerField(default=0)
    posicao_final = models.IntegerField()
    pontuacao = models.ForeignKey(Pontuacao, on_delete=models.SET_NULL, null=True, blank=True, related_name='resultados')

    class Meta:
        unique_together = ('piloto', 'corrida')

    def __str__(self):
        return f"{self.piloto.nome} - {self.corrida.nome} ({self.posicao_final}º)"

class Classificacao(models.Model):
    temporada = models.ForeignKey(Temporada, on_delete=models.CASCADE, related_name='classificacoes')
    piloto = models.ForeignKey(Piloto, on_delete=models.CASCADE, related_name='classificacoes')
    pontos_totais = models.IntegerField(default=0)

    class Meta:
        unique_together = ('temporada', 'piloto')

    def __str__(self):
        return f"{self.piloto.nome} - Temporada {self.temporada.ano}: {self.pontos_totais} pontos"

class Carro(models.Model):
    modelo = models.CharField(max_length=100)
    equipe = models.ForeignKey(Equipe, on_delete=models.CASCADE, related_name='carros')
    temporada = models.ForeignKey(Temporada, on_delete=models.CASCADE, related_name='carros')
    ano = models.IntegerField()
    motor = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.modelo} ({self.equipe.nome} - {self.ano})"

class Penalidade(models.Model):
    TIPO_PENALIDADE_CHOICES = [
    ('POSICAO', 'Penalidade de Posição'),
    ]
    piloto = models.ForeignKey(Piloto, on_delete=models.CASCADE, related_name='penalidades')
    corrida = models.ForeignKey(Corrida, on_delete=models.CASCADE, related_name='penalidades')
    motivo = models.TextField()
    penalidade_aplicada = models.PositiveIntegerField()
    tipo_penalidade = models.CharField(max_length=100, choices=TIPO_PENALIDADE_CHOICES, default='POSICAO')

    def __str__(self):
        return f"Penalidade para {self.piloto.nome} na {self.corrida.nome}: {self.penalidade_aplicada}"