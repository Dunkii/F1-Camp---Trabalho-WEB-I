from django.contrib import admin
from .models import (Piloto, Equipe, Corrida, Circuito, Resultado,Temporada, Pontuacao, Classificacao, Carro, Penalidade)

@admin.register(Piloto)
class PilotoAdmin(admin.ModelAdmin):
    list_display = ('nome', 'nacionalidade', 'numero', 'equipe')
    list_filter = ('equipe', 'nacionalidade')
    search_fields = ('nome', 'nacionalidade')

@admin.register(Equipe)
class EquipeAdmin(admin.ModelAdmin):
    list_display = ('nome', 'pais', 'motor')
    list_filter = ('pais', 'motor')
    search_fields = ('nome', 'pais')

@admin.register(Corrida)
class CorridaAdmin(admin.ModelAdmin):
    list_display = ('nome', 'data', 'circuito', 'temporada')
    list_filter = ('temporada', 'circuito')
    search_fields = ('nome', 'circuito__nome')
    date_hierarchy = 'data'

@admin.register(Circuito)
class CircuitoAdmin(admin.ModelAdmin):
    list_display = ('nome', 'localizacao', 'distancia', 'numero_voltas')
    list_filter = ('localizacao',)
    search_fields = ('nome', 'localizacao')

@admin.register(Resultado)
class ResultadoAdmin(admin.ModelAdmin):
    list_display = ('piloto', 'corrida', 'posicao_final', 'pontuacao')
    list_filter = ('temporada', 'corrida', 'piloto', 'posicao_final')
    search_fields = ('piloto__nome', 'corrida__nome')
    raw_id_fields = ('piloto', 'corrida', 'temporada', 'pontuacao')

@admin.register(Temporada)
class TemporadaAdmin(admin.ModelAdmin):
    list_display = ('ano', 'numero_corridas', 'vencedor')
    list_filter = ('ano',)
    search_fields = ('ano',)
    raw_id_fields = ('vencedor',)

@admin.register(Pontuacao)
class PontuacaoAdmin(admin.ModelAdmin):
    list_display = ('tipo_corrida', 'posicao', 'pontos')
    list_filter = ('tipo_corrida',)
    search_fields = ('posicao', 'pontos', 'tipo_corrida__tipo')

@admin.register(Classificacao)
class ClassificacaoAdmin(admin.ModelAdmin):
    list_display = ('temporada', 'piloto', 'pontos_totais')
    list_filter = ('temporada', 'piloto')
    search_fields = ('piloto__nome', 'temporada__ano')
    raw_id_fields = ('piloto', 'temporada')

@admin.register(Carro)
class CarroAdmin(admin.ModelAdmin):
    list_display = ('modelo', 'equipe', 'ano', 'motor')
    list_filter = ('equipe', 'ano', 'motor')
    search_fields = ('modelo', 'equipe__nome')
    raw_id_fields = ('equipe', 'temporada')

@admin.register(Penalidade)
class PenalidadeAdmin(admin.ModelAdmin):
    list_display = ('piloto', 'corrida', 'motivo', 'penalidade_aplicada')
    list_filter = ('piloto', 'corrida')
    search_fields = ('piloto__nome', 'corrida__nome', 'motivo')
    raw_id_fields = ('piloto', 'corrida')